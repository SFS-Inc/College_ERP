from django.shortcuts import render
from django.contrib.auth.decorators import login_required, user_passes_test

@login_required
def faculty_dashboard(request):
    # Get list of group names for this user (e.g. ['Faculty', 'Faculty_Admin'])
    user_groups = list(request.user.groups.values_list('name', flat=True))
    
    return render(request, 'users/dashboard.html', {
        'user_groups': user_groups
    })

@login_required
def profile(request):
    return render(request, 'users/profile.html') # Dummy page

# --- NEW FUNCTION ---
def is_faculty_admin(user):
    return user.groups.filter(name='Faculty_Admin').exists()

@login_required
@user_passes_test(is_faculty_admin) # Security: Only Admins can see this page!
def admin_menu(request):
    return render(request, 'users/admin_menu.html')