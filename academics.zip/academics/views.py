from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Department, Semester, Batch, Subject, ClassLog, Chapter, Topic, AcademicSession
from .forms import SubjectForm 

# ==========================================
# 1. LOG ENGAGEMENT (The Main Feature)
# ==========================================

@login_required
def log_engagement(request):
    """
    Renders the main form where faculty enter data.
    Handles both Showing the form (GET) and Saving the data (POST).
    """
    if request.method == "POST":
        try:
            # --- 1. Get Raw Data from Form ---
            subject_id = request.POST.get('subject')
            batch_id = request.POST.get('batch')
            chapter_id = request.POST.get('chapter')
            topic_name = request.POST.get('topic') 
            date = request.POST.get('date')
            duration = request.POST.get('duration')

            # --- 2. Get Database Objects ---
            subject = Subject.objects.get(id=subject_id)
            batch = Batch.objects.get(id=batch_id)

            # --- 3. Smart Topic Logic ---
            if chapter_id:
                chapter = Chapter.objects.get(id=chapter_id)
            else:
                # Fallback: Create a "General" chapter if none selected
                chapter, _ = Chapter.objects.get_or_create(
                    subject=subject,
                    name="General Class Logs",
                    defaults={'added_by': request.user}
                )

            # Smart Topic: Get ID if dropdown used, or Create if text typed
            topic_id_or_name = request.POST.get('topic')
            if topic_id_or_name and topic_id_or_name.isdigit():
                 topic = Topic.objects.get(id=topic_id_or_name)
            else:
                topic, _ = Topic.objects.get_or_create(
                    chapter=chapter,
                    name=topic_id_or_name
                )

            # --- 4. Get Active Session ---
            active_session = AcademicSession.objects.filter(is_active=True).first()
            if not active_session:
                active_session = AcademicSession.objects.last()

            # --- 5. Save the Log ---
            ClassLog.objects.create(
                faculty=request.user,
                session=active_session,
                subject=subject,
                batch=batch,
                chapter=chapter,
                topic=topic,
                date=date if date else "2025-11-25",
                duration_hours=duration
            )
            
            messages.success(request, "✅ Class logged successfully!")
            return redirect('faculty_dashboard')

        except Exception as e:
            messages.error(request, f"Error saving log: {str(e)}")
    
    # --- GET Request ---
    departments = Department.objects.all()
    my_subjects = Subject.objects.filter(faculty=request.user).select_related('semester', 'department')

    return render(request, 'academics/log_form.html', {
        'departments': departments,
        'my_subjects': my_subjects
    })

@login_required
def faculty_history(request):
    """ Shows the list of past logs for the logged-in teacher. """
    logs = ClassLog.objects.filter(faculty=request.user).select_related('subject', 'batch', 'topic').order_by('-date')
    return render(request, 'academics/history.html', {'logs': logs})

@login_required
def delete_log(request, log_id):
    """ Allows faculty to delete their own logs from history. """
    log = get_object_or_404(ClassLog, id=log_id, faculty=request.user)
    
    if request.method == "POST":
        log.delete()
        messages.success(request, "Log entry deleted.")
        return redirect('faculty_history')
    
    return render(request, 'academics/confirm_delete.html', {'object': log, 'type': 'Log Entry'})

@login_required
def faculty_dashboard(request):
    return render(request, 'users/dashboard.html')


# ==========================================
# 2. SUBJECT MANAGER (Admin/Faculty Feature)
# ==========================================

@login_required
def manage_subjects(request):
    """
    List subjects. 
    - Faculty Admins see ALL subjects.
    - Regular Faculty see only THEIR subjects.
    """
    is_admin = request.user.groups.filter(name='Faculty_Admin').exists()

    if is_admin:
        subjects = Subject.objects.all().select_related('department', 'semester', 'faculty').order_by('department', 'code')
    else:
        subjects = Subject.objects.filter(faculty=request.user).select_related('department', 'semester').order_by('code')

    return render(request, 'academics/manage_subjects.html', {
        'subjects': subjects,
        'is_admin': is_admin
    })

@login_required
def add_subject(request):
    """ Create a new subject. """
    if request.method == 'POST':
        form = SubjectForm(request.POST)
        if form.is_valid():
            subject = form.save(commit=False)
            subject.faculty = request.user
            subject.save()
            messages.success(request, f"Subject '{subject.name}' created successfully!")
            return redirect('manage_subjects')
    else:
        form = SubjectForm()
    
    return render(request, 'academics/subject_form.html', {'form': form, 'title': 'Add New Subject'})

@login_required
def edit_subject(request, subject_id):
    """ Edit an existing subject. """
    is_admin = request.user.groups.filter(name='Faculty_Admin').exists()

    if is_admin:
        subject = get_object_or_404(Subject, id=subject_id)
    else:
        subject = get_object_or_404(Subject, id=subject_id, faculty=request.user)
    
    if request.method == 'POST':
        form = SubjectForm(request.POST, instance=subject)
        if form.is_valid():
            form.save()
            messages.success(request, "Subject updated successfully!")
            return redirect('manage_subjects')
    else:
        form = SubjectForm(instance=subject)
    
    return render(request, 'academics/subject_form.html', {'form': form, 'title': f'Edit {subject.code}'})

@login_required
def delete_subject(request, subject_id):
    """ Delete a subject safely. """
    is_admin = request.user.groups.filter(name='Faculty_Admin').exists()

    if is_admin:
        subject = get_object_or_404(Subject, id=subject_id)
    else:
        subject = get_object_or_404(Subject, id=subject_id, faculty=request.user)
    
    if request.method == "POST":
        name = subject.name
        subject.delete()
        messages.success(request, f"Subject '{name}' has been deleted.")
        return redirect('manage_subjects')
    
    return render(request, 'academics/confirm_delete.html', {'object': subject, 'type': 'Subject'})


# ==========================================
# 3. HTMX PARTIALS (Dropdown Logic)
# ==========================================

@login_required
def get_semesters(request):
    semesters = Semester.objects.all().order_by('name')
    return render(request, 'academics/partials/options_semester.html', {'options': semesters})

@login_required
def get_batches(request):
    department_id = request.GET.get('department')
    semester_id = request.GET.get('semester')
    
    if not department_id or not semester_id:
        return render(request, 'academics/partials/options_batch.html', {'options': []})

    batches = Batch.objects.filter(department_id=department_id, semester_id=semester_id).order_by('name')
    return render(request, 'academics/partials/options_batch.html', {'options': batches})

@login_required
def get_chapters(request):
    subject_id = request.GET.get('subject')
    
    if not subject_id:
        return render(request, 'academics/partials/options_chapter.html', {'options': []})

    chapters = Chapter.objects.filter(subject_id=subject_id).order_by('name')
    return render(request, 'academics/partials/options_chapter.html', {'options': chapters})

@login_required
def get_topics(request):
    chapter_id = request.GET.get('chapter')

    if not chapter_id:
        return render(request, 'academics/partials/options_topic.html', {'options': []})

    topics = Topic.objects.filter(chapter_id=chapter_id).order_by('name')
    return render(request, 'academics/partials/options_topic.html', {'options': topics})